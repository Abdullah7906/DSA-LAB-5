#include "node.h"

Node::Node(int val) {
    data = val;
    prev = NULL;
    next = NULL;
}
